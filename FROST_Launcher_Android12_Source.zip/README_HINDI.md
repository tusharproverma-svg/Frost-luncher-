# FROST Launcher — Android 12

यह शुरुआती Android Studio प्रोजेक्ट दो PIN से दो अलग Launcher Home Screens और अलग-अलग App Shortcuts देता है।

## इसमें क्या काम करता है
- पहली बार दो अलग PIN सेट करना (कम से कम 4 अंक)
- PIN A से Personal Space, PIN B से Private Space खोलना
- हर Space के लिए अलग चुने हुए App Shortcuts सेव करना
- चुने हुए ऐप सीधे खोलना
- Space बदलने पर Launcher Login पर लौटना
- डार्क नेवी + साइयन UI

## जरूरी सुरक्षा सीमा
यह **दो Android users / पूर्ण secure sandbox नहीं** है। दोनों Spaces एक ही Android user और एक ही ऐप डेटा/डिवाइस में चलते हैं। PIN केवल FROST Launcher के UI को लॉक करता है। अन्य Android ऐप्स, Settings, Recents, Notifications या फाइलों को इससे अलग/छिपाया नहीं जाता। असली डेटा अलगाव के लिए Android का Multiple Users / अलग managed profile चाहिए, यदि डिवाइस निर्माता ने उपलब्ध कराया हो।

PIN का SHA-256 hash SharedPreferences में रखा जाता है, लेकिन यह ऐप को उच्च-सुरक्षा Vault नहीं बनाता। संवेदनशील ऐप/डेटा की सुरक्षा के लिए Android screen lock और संबंधित ऐप की अपनी सुरक्षा इस्तेमाल करें।

## Android Studio से APK बनाना
1. Android Studio में इस फ़ोल्डर को Open करें।
2. Gradle sync पूरा होने दें। JDK 17 इस्तेमाल करें।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।
5. टैबलेट में APK इंस्टॉल करें।
6. Settings > Apps > Default apps > Home app (या Home app chooser) में FROST Launcher चुनें।

## डिवाइस पर परीक्षण
- Android 12 / Lenovo Tab K10 पर जांचें।
- पहली बार अलग-अलग PIN बनाएं।
- Personal में कुछ ऐप चुनें, फिर Lock करके Private PIN डालें और अलग ऐप चुनें।
- दोबारा Personal PIN से जाँचें।

## नोट
यह source project है; इस वातावरण में Android SDK/Gradle build चलाकर APK सत्यापित नहीं किया गया है। इसलिए इसे compiled/tested APK न समझें।
