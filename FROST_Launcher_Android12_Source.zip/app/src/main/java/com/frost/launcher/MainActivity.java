package com.frost.launcher;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.security.MessageDigest;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(7,13,25), PANEL=Color.rgb(15,29,49), CYAN=Color.rgb(57,191,255), WHITE=Color.WHITE;
    private android.content.SharedPreferences prefs;
    private String activeSpace="";
    private LinearLayout root, body;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        prefs=getSharedPreferences("frost_spaces", MODE_PRIVATE);
        if (!prefs.contains("pinA")) setupScreen(); else loginScreen();
    }

    private void base(String title) {
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(22,26,22,18); root.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this); body=new LinearLayout(this); body.setOrientation(1); body.setPadding(0,8,0,8);
        TextView heading=label("❄ FROST",28,CYAN,true); root.addView(heading);
        TextView sub=label(title,15,WHITE,true); root.addView(sub);
        View line=new View(this); line.setBackgroundColor(CYAN); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,2); lp.setMargins(0,14,0,12); root.addView(line,lp);
        scroll.addView(body); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    private TextView label(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(4,8,4,8); return t;
    }
    private EditText edit(String hint) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setHintTextColor(0xff91a8bd); e.setTextColor(WHITE);
        e.setInputType( android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setPadding(18,12,18,12); e.setBackgroundColor(PANEL); return e;
    }
    private Button button(String text,Runnable action) {
        Button b=new Button(this); b.setText(text); b.setTextColor(WHITE); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff123b59));
        b.setOnClickListener(v->action.run()); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,8,0,8); body.addView(b,p); return b;
    }
    private void setupScreen() {
        base("पहली बार सेटअप • दो अलग Home Screens");
        body.addView(label("दो अलग PIN बनाएँ। PIN भूलने पर ऐप डेटा साफ़ करना पड़ सकता है।",14,0xffc6d8e8,false));
        EditText a=edit("Personal Space PIN (कम से कम 4 अंक)"); body.addView(a);
        EditText b=edit("Private Space PIN (Personal से अलग)"); body.addView(b);
        button("दोनों PIN सेव करें",()->{
            String x=a.getText().toString(), y=b.getText().toString();
            if(x.length()<4 || y.length()<4 || x.equals(y)){ msg("दो अलग-अलग कम से कम 4 अंकों के PIN डालें।"); return; }
            prefs.edit().putString("pinA",hash(x)).putString("pinB",hash(y)).apply();
            loginScreen();
        });
        body.addView(label("नोट: यह Launcher के अंदर PIN gate है, Android का असली अलग/एन्क्रिप्टेड user profile नहीं।",12,0xffffcf7a,false));
    }
    private void loginScreen() {
        base("Secure Space Login");
        body.addView(label("अपना PIN डालें। अलग PIN से अलग Home Screen खुलेगी।",14,0xffc6d8e8,false));
        EditText pin=edit("PIN"); body.addView(pin);
        button("UNLOCK",()->{
            String h=hash(pin.getText().toString());
            if(h.equals(prefs.getString("pinA",""))) { activeSpace="A"; homeScreen(); }
            else if(h.equals(prefs.getString("pinB",""))) { activeSpace="B"; homeScreen(); }
            else msg("गलत PIN");
        });
        button("PIN बदलने / रीसेट करने के लिए ऐप डेटा साफ़ करें",()->new AlertDialog.Builder(this)
            .setMessage("इससे दोनों Spaces की सेटिंग और PIN मिट जाएँगे। आगे बढ़ें?")
            .setNegativeButton("रद्द",null).setPositiveButton("रीसेट", (d,w)->{prefs.edit().clear().apply(); setupScreen();}).show());
    }
    private void homeScreen() {
        String name=activeSpace.equals("A")?"PERSONAL SPACE":"PRIVATE SPACE";
        base(name);
        body.addView(label(activeSpace.equals("A")?"आपकी पहली Home Screen":"आपकी दूसरी Home Screen",20,CYAN,true));
        body.addView(label("इस Space के लिए ऐप चुनें। दोनों Spaces की चुनी हुई सूची अलग सेव होती है।",13,0xffc6d8e8,false));
        button("＋ इस Space में Apps चुनें",()->appPicker());
        button("↻ Space बदलें / Lock",()->loginScreen());
        button("⚙ PIN सेटिंग रीसेट",()->new AlertDialog.Builder(this).setMessage("रीसेट करने से दोनों Spaces की ऐप सूची और PIN मिट जाएँगे।").setNegativeButton("रद्द",null).setPositiveButton("रीसेट",(d,w)->{prefs.edit().clear().apply();setupScreen();}).show());
        Set<String> selected=prefs.getStringSet("apps"+activeSpace,new HashSet<String>());
        if(selected.isEmpty()) body.addView(label("अभी कोई Shortcut नहीं है। ऊपर से Apps चुनें।",14,0xff91a8bd,false));
        else {
            for(String pkg:new TreeSet<>(selected)) {
                try {
                    ApplicationInfo ai=getPackageManager().getApplicationInfo(pkg,0);
                    String appName=getPackageManager().getApplicationLabel(ai).toString();
                    Button b=button("▣  "+appName,()->launch(pkg));
                    b.setCompoundDrawablesWithIntrinsicBounds(getPackageManager().getApplicationIcon(ai),null,null,null);
                } catch(Exception ignored) {}
            }
        }
    }
    private void appPicker() {
        base("Choose Apps • "+(activeSpace.equals("A")?"Personal":"Private"));
        Set<String> chosen=new HashSet<>(prefs.getStringSet("apps"+activeSpace,new HashSet<String>()));
        List<ResolveInfo> apps=getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0);
        Collections.sort(apps,(x,y)->String.CASE_INSENSITIVE_ORDER.compare(x.loadLabel(getPackageManager()).toString(),y.loadLabel(getPackageManager()).toString()));
        Map<String,CheckBox> checks=new LinkedHashMap<>();
        for(ResolveInfo ri:apps) {
            String pkg=ri.activityInfo.packageName;
            if(pkg.equals(getPackageName())) continue;
            CheckBox c=new CheckBox(this); c.setText(ri.loadLabel(getPackageManager())); c.setTextColor(WHITE); c.setButtonTintList(android.content.res.ColorStateList.valueOf(CYAN)); c.setChecked(chosen.contains(pkg));
            body.addView(c); checks.put(pkg,c);
        }
        button("SAVE SHORTCUTS",()->{
            Set<String> result=new HashSet<>(); for(String pkg:checks.keySet()) if(checks.get(pkg).isChecked()) result.add(pkg);
            prefs.edit().putStringSet("apps"+activeSpace,result).apply(); homeScreen();
        });
        button("वापस",()->homeScreen());
    }
    private void launch(String pkg) {
        Intent i=getPackageManager().getLaunchIntentForPackage(pkg);
        if(i!=null) try { startActivity(i); } catch(Exception e){msg("ऐप नहीं खुल सका");}
        else msg("इस ऐप का Launch Shortcut उपलब्ध नहीं है।");
    }
    private String hash(String s) {
        try { byte[] d=MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8")); StringBuilder out=new StringBuilder(); for(byte b:d) out.append(String.format("%02x",b)); return out.toString(); }
        catch(Exception e){return s;}
    }
    private void msg(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
